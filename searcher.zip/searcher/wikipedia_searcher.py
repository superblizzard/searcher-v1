import os
import re
import common
import numpy as np
import spacy
import faiss
import whoosh
from transformers import T5Tokenizer, T5ForConditionalGeneration
from sentence_transformers import SentenceTransformer
from whoosh.qparser import QueryParser, OrGroup
from datetime import datetime
nlp = spacy.load("en_core_web_sm")

faiss_index_name = "faiss_index.bin"
faiss_index = None

term_index = whoosh.index.open_dir("indexdir")
searcher = term_index.searcher()
embedding_model = SentenceTransformer('all-mpnet-base-v2')


model_name = "google/flan-t5-base"
tokenizer = T5Tokenizer.from_pretrained(model_name)
model = T5ForConditionalGeneration.from_pretrained(model_name)


# Function to rephrase a query into a statement
def rephrase_query_to_statement(query):
    # Add an instruction prefix to guide the model
    input_text = f"Rephrase the following question as a statement: {query}"
    # Tokenize the input
    inputs = tokenizer(input_text, return_tensors="pt", max_length=512, truncation=True)
    # Generate output
    output_ids = model.generate(inputs.input_ids, max_length=20, num_beams=4, early_stopping=True)
    # Decode the generated output
    return tokenizer.decode(output_ids[0], skip_special_tokens=True)


def preprocess(text):
    return re.sub(r'[^\w\s]', '', text).lower()


def create_query_embedding(query):
    return embedding_model.encode(query).reshape(1, -1)


TIME_SENSITIVE_KEYWORDS = [
    "who", "what", "when", "where", "how many", "latest", "recent", "history", "record",
    "trend", "growth", "ranking", "leader", "winner", "CEO", "president", "prime minister",
    "population", "temperature", "GDP", "inflation", "unemployment"
]

# Keywords that often require location-based context
LOCATION_SENSITIVE_KEYWORDS = [
    "weather", "temperature", "population", "GDP", "laws", "elections", "cases",
    "headquarters", "company", "government", "travel", "tourism", "disaster"
]


def smart_query_expansion(query, default_location="United States"):
    doc = nlp(query)
    entities = {ent.label_ for ent in doc.ents}  # Extract entity labels
    for token in doc:
        if token.pos_ == "ADP":
            return query
    expanded_query = query.lower()  # Normalize case for comparison
    # Add time if the query contains time-sensitive words but lacks a date
    if "DATE" not in entities and "DATE" not in entities and any(word in expanded_query for word in TIME_SENSITIVE_KEYWORDS):
        expanded_query += f" in {datetime.now().year}"
    # Add location if the query contains location-sensitive words but lacks a GPE (Geopolitical Entity)
    if "GPE" not in entities and any(word in expanded_query for word in LOCATION_SENSITIVE_KEYWORDS):
        expanded_query += f" in {default_location}"
    return expanded_query


def search_faiss(original_query, extended_query, top_k=20, try_again=True):
    query_embedding = create_query_embedding(extended_query)
    distances, indices = faiss_index.search(query_embedding, top_k)
    scores = 1 / (1 + distances)
    max_score = np.max(scores)

    if try_again and max_score < 0.5:
        rephrased_query = rephrase_query_to_statement(original_query)
        if len(rephrased_query) > 0:
            return search_faiss(original_query, rephrased_query, 20, try_again=False)

    results = []
    for idx, score in zip(indices[0], scores[0]):
        results.append({
            "id": idx,
            "score": score,
            "normalized_score": score / (max_score + 1e-2), # normalize to [0, 1]
        })
    return results


def search_term(original_query, extended_query, top_k=20, try_again=True):
    results = []
    group = OrGroup.factory(1.0)
    if not try_again:
        group = OrGroup.factory(0.6)
    query_parser = QueryParser("content", term_index.schema, group=group).parse(extended_query)
    hits = searcher.search(query_parser, limit=top_k)
    if len(hits) > 0:
        max_score = max(hit.score for hit in hits)
        for hit in hits:
            results.append({
                "id": hit["id"],
                "text": hit["text"],
                "score": hit.score,
                "normalized_score": hit.score / (max_score + 1e-3),
            })
    elif try_again:
        extended_terms = common.expand_terms(original_query)
        return search_term(extended_terms, original_query, top_k=20, try_again=False)

    return results


def main():
    if os.path.exists(faiss_index_name):
        try:
            print("Attempting to load FAISS index...")
            global faiss_index
            faiss_index = faiss.read_index(faiss_index_name)
            print("FAISS index loaded successfully.")
        except Exception as e:
            print(f"Failed to load FAISS index: {e}")
    else:
        print("FAISS index file does not exist.")

    print("Wikipedia Search CLI. Type a query or 'exit' to quit.")
    while True:
        query = input("Search: ")
        if query.lower() == "exit":
            break

        expanded_query = smart_query_expansion(query)

        faiss_results = search_faiss(query, expanded_query)
        term_results = search_term(query, expanded_query)

        results = []
        id1s = {item["id"] for item in faiss_results}
        id2s = {item["id"] for item in term_results}
        common_ids = id1s.intersection(id2s)

        for faiss_result in faiss_results:
            if faiss_result["id"] in common_ids:
                term_result = next((item for item in term_results if item["id"] == faiss_result["id"]), None)
                results.append({
                    "source": "both",
                    "text": term_result["text"],
                    # need to tune later
                    "score": term_result["normalized_score"] * 0.3 + faiss_result["normalized_score"] * 0.7 + 0.1,
                })
            else:
                results.append({
                    "source": "faiss",
                    "text": searcher.stored_fields(faiss_result["id"])["text"],
                    "score": faiss_result["normalized_score"],
                })

        for term_result in term_results:
            if term_result["id"] in common_ids:
                continue
            results.append({
                "source": "whoosh",
                "text": term_result["text"],
                "score": term_result["normalized_score"],
            })

        if not results:
            print("No results found.")
        else:
            results = sorted(results, key=lambda item: item["score"], reverse=True)
            print(f"\nTop 10 results for '{query}':")
            for i, result in enumerate(results[:10], 1):
                print(f"\nResult {i}: (score : {result['score']}), (source : {result['source']})")
                print(f"Content: {result['text'].strip()[:150]}...")
        print("\n")


if __name__ == "__main__":
    main()
