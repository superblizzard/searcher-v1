import faiss
import numpy as np
import spacy
import common
from sentence_transformers import SentenceTransformer
from whoosh import index
from whoosh.fields import Schema, TEXT, ID, STORED
import os

index_dir = "indexdir"
os.makedirs(index_dir, exist_ok=True)
# Define schema with TF-IDF scoring
schema = Schema(id=STORED, content=TEXT(stored=False), text=STORED)
ix = index.create_in(index_dir, schema)
folder_path = "data"
writer = ix.writer()
nlp = spacy.load("en_core_web_sm")


def clean_name(name):
    name, _ = os.path.splitext(name)  # Remove file extension
    return name.replace("_", " ")


def get_sentences_from_page(paragraph):
    try:
        doc = nlp(paragraph)  # Process the paragraph with spaCy
        return [sent.text.strip() for sent in doc.sents]  # Extract sentences and remove extra whitespace
    except Exception as e:
        print(f"An error occurred: {e}")
        return []


faiss_index_name = "faiss_index.bin"
embedding_model = SentenceTransformer('all-mpnet-base-v2')
d = 768  # Embedding dimension
index = faiss.IndexFlatL2(d)

raw_data = []

for filename in os.listdir(folder_path):

    file_path = os.path.join(folder_path, filename)
    clean_filename = clean_name(filename)
    if os.path.isfile(file_path):  # Ensure it's a file
        with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
            visited_content = set()
            for line in f:
                complete_line = clean_filename + " : " + line
                if line in visited_content:
                    continue
                visited_content.add(line)
                writer.add_document(id=len(raw_data), content=line, text=complete_line)
                raw_data.append(complete_line)
                truncated_length = 80
                # for line paragraph, split it into shorter sentence
                if len(line) > truncated_length:
                    sentences = get_sentences_from_page(line)
                    for sentence in sentences:
                        if len(sentence) < 10:
                            continue
                        if sentence in visited_content:
                            continue
                        visited_content.add(sentence)
                        truncated_sentence = sentence
                        if len(sentence) > truncated_length:
                            truncated_sentence = sentence[:truncated_length]
                        # add synonyms
                        extra_terms = common.expand_terms(truncated_sentence)
                        #print(extra_terms)
                        comp_sentence = complete_line + " " + sentence + " " + extra_terms
                        writer.add_document(id=len(raw_data), content=comp_sentence, text=sentence)
                        raw_data.append(truncated_sentence)

        print(f"Indexed: {filename}")

writer.commit()  # Save changes

# add faiss index
print("embedding...")
embeddings = embedding_model.encode(raw_data)
print("faiss indexing...")
index.add(np.array(embeddings, dtype=np.float32))
faiss.write_index(index, faiss_index_name)
print(f"Total indexed record: {len(raw_data)}")


