
import nltk
import spacy
from rake_nltk import Rake
from transformers import BertTokenizer, BertForTokenClassification, pipeline
from nltk.corpus import wordnet

nltk.download('stopwords')
nltk.download('punkt_tab')
nltk.download("wordnet")
nlp = spacy.load("en_core_web_sm")

rake_extractor = Rake()
tokenizer = BertTokenizer.from_pretrained("dbmdz/bert-large-cased-finetuned-conll03-english")
model = BertForTokenClassification.from_pretrained("dbmdz/bert-large-cased-finetuned-conll03-english")
# Create the NER pipeline
nlp_ner = pipeline("ner", model=model, tokenizer=tokenizer)


def extract_phrases_with_bert(sentence):
    ner_results = nlp_ner(sentence)
    entities = {}
    for result in ner_results:
        label = result['entity']
        entity = result['word']
        if label not in entities:
            entities[label] = []
        entities[label].append(entity)
    return entities


def extract_keywords(query):
    # Extract keywords
    rake_extractor.extract_keywords_from_text(query)
    # Get the keywords with scores
    keywords = rake_extractor.get_ranked_phrases_with_scores()
    return [keyword[1] for keyword in keywords[:5]]


def get_word_synonyms(word):
    synonyms = set()
    for syn in wordnet.synsets(word):
        for lemma in syn.lemmas():
            synonyms.add(lemma.name().replace("_", " "))
    return list(synonyms)


def get_phrase_synonyms(phrase):
    """Find synonyms for a multi-word phrase in WordNet"""
    synonyms = set()
    for synset in wordnet.synsets(phrase.replace(" ", "_")):  # WordNet uses underscores for phrases
        for lemma in synset.lemmas():
            synonyms.add(lemma.name().replace("_", " "))  # Convert underscores back to spaces

    return list(synonyms)


def get_word_synonyms_from_sentence(sentence, exclusive_words):
    """Find synonyms for a multi-word phrase in WordNet"""
    synonyms = set()

    doc = nlp(sentence)
    important_words = [token.text for token in doc if token.pos_ in ['NOUN', 'VERB', 'ADJ']]
    filtered_words = [item for item in important_words if item not in exclusive_words]

    for word in filtered_words:
        syns = get_word_synonyms(word)
        synonyms.update(syns)

    return list(synonyms)


def extract_named_entities(sentence):
    results = nlp_ner(sentence)
    entities = []
    current_entity = {}

    for result in results:
        word = result['word']
        entity_label = result['entity']  # Use 'entity' instead of 'entity_group'
        score = result['score']

        # Skip non-entity tokens ('O' means no entity)
        if entity_label == "O":
            continue

        # Extract the entity type (e.g., 'PER' from 'B-PER')
        entity_type = entity_label[2:]  # Remove the 'B-' or 'I-' prefix

        if not current_entity or current_entity['type'] != entity_type:
            if current_entity:
                entities.append(current_entity)
            current_entity = {'text': word, 'type': entity_type, 'score': score}
        else:
            if word.startswith("##"):
                current_entity['text'] += word[2:]
            else:
                current_entity['text'] += ' ' + word

    if current_entity:
        entities.append(current_entity)

    values_list = [d['text'] for d in entities]

    return values_list


def extract_phrases_spacy(sentence):
    doc = nlp(sentence)
    phrases = []
    for chunk in doc.noun_chunks:
        phrases.append(chunk.text)

    for token in doc:
        if token.pos_ == "VERB":
            phrase = token.text
            # Extend to the left for auxiliaries/adverbs
            left_token = token.left_edge
            while left_token.pos_ in ("AUX", "ADV", "PART"): #Added "PART" to include words like "up" in "jumps up"
                phrase = left_token.text + " " + phrase
                left_token = left_token.left_edge

            phrases.append(phrase)

    return phrases


def extract_all_possible_phrases(sentence):
    """Extract all possible phrases from a sentence."""
    # Extract named entities using bert-base-NER
    named_entities = extract_named_entities(sentence)
    # Extract noun and verb phrases using spaCy
    #phrases = extract_phrases_spacy(sentence)

    keywords = extract_keywords(sentence)

    return list(set(named_entities + keywords))


def expand_terms(sentence):
    outputs = []
    phrases = extract_all_possible_phrases(sentence)
    visited_word = set()
    for phrase in phrases:
        visited_word.update(phrase.split())
        phrase_synonyms = get_phrase_synonyms(phrase)
        outputs.extend(phrase_synonyms)

    # word_syns = get_word_synonyms_from_sentence(sentence, visited_word)
    # outputs.extend(word_syns)
    return " ".join(set(outputs))