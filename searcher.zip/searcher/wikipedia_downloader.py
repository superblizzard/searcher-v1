import os
from io import StringIO

import coreferee, spacy
import pandas as pd
import requests
import wikipediaapi
from bs4 import BeautifulSoup
from transformers import  pipeline, BertTokenizer, BertForTokenClassification


nlp = spacy.load("en_core_web_sm")
nlp.add_pipe('coreferee')
tokenizer = BertTokenizer.from_pretrained("dbmdz/bert-large-cased-finetuned-conll03-english")
model = BertForTokenClassification.from_pretrained("dbmdz/bert-large-cased-finetuned-conll03-english")

# Create the NER pipeline
nlp_ner = pipeline("ner", model=model, tokenizer=tokenizer)

# Create an index directory
if not os.path.exists("indexdir"):
    os.mkdir("indexdir")

faiss_index = "faiss_index.index"

wiki_categories = [
    #'Philosophy',
    #'Python (programming language)',
    "UEFA Champions League",
    "Presidents of the United States",
    #'CSS (stylesheet language)',
    #'School of Athens'
]

# Initialize Wikipedia API and Embedding Model
wiki = wikipediaapi.Wikipedia(
    language="en",
    user_agent="WikiSearchCLI/1.0 (contact: bookblizzard@gmail.com)"
)


def summarize_text(text, max_length=20):
    print(text)
    if len(text) < 20:
        return text
    if len(text) < max_length:
        max_length = len(text)-1

    prompt = f"Summarize the following text in {max_length} words:\n{text}\nSummary:"
    response = model.generate(prompt, max_tokens=max_length)
    return response.strip()


def download_data_from_category(category_title, depth=0, max_depth=2):
    category_page = wiki.page(f"Category:{category_title}")
    if not category_page.exists():
        print(f"Category '{category_title}' does not exist.")
        return []
    print("Indexing category :", category_title)

    def recursive_traverse(page, current_depth):
        if current_depth > max_depth:
            return

        is_category = page.text.strip().lower().startswith("category")
        print(page.title.strip())
        if not is_category and page.namespace == wikipediaapi.Namespace.MAIN:
            name = "_".join(page.title.strip().split())
            file_path = os.path.join("data", name + ".txt")
            os.makedirs("data", exist_ok=True)
            file = open(file_path, "w", encoding="utf-8")
            file.write(f"{resolve_coreferences(page.summary)}\n")
            sentences = read_tables(name)
            if len(sentences) > 0:
                for sentence in sentences:
                    file.write(f"{sentence}\n")
            file.close()
        if page.namespace == wikipediaapi.Namespace.CATEGORY:
            for member_title, member in page.categorymembers.items():
                recursive_traverse(member, current_depth + 1)

    recursive_traverse(category_page, depth)
    return []


def read_tables(target):
    url = "https://en.wikipedia.org/wiki/" + target
    sentences = []
    response = requests.get(url)
    if response.status_code != 200:
        return sentences
    soup = BeautifulSoup(response.text, "html.parser")
    tables = soup.find_all("table", {"class": "wikitable"})
    if not tables:
        return sentences

    for table in tables:
        table_html = str(table)  # Convert the table to string
        df = pd.read_html(StringIO(table_html))[0]
        for index, row in df.iterrows():
            sentence = ", ".join([f"{col}: {value}" for col, value in row.items()])
            sentences.append(sentence)

    return sentences


def download_wikipedia_articles(categories):
    for category in categories:
        data_in_category = download_data_from_category(category)
        if len(data_in_category) == 0:
            print(f"No page found from category {category}")


def get_sentences_from_page(paragraph):
    try:
        doc = nlp(paragraph)  # Process the paragraph with spaCy
        return [sent.text.strip() for sent in doc.sents]  # Extract sentences and remove extra whitespace
    except Exception as e:
        print(f"An error occurred: {e}")
        return []


def count_words(sentence):
    doc = nlp(sentence)
    words = [token.text for token in doc if not token.is_punct and not token.is_space] # Remove punctuation and spaces
    return len(words)


def resolve_coreferences(text):
    doc = nlp(text)
    resolved_text = ""
    for token in doc:
        if token.is_punct:
            resolved_text += token.text
        else:
            repres = doc._.coref_chains.resolve(token)
            if repres:
                resolved_text += " " + " and ".join([t.text for t in repres])
            else:
                resolved_text += " " + token.text

    return resolved_text.strip()


def main():
    download_wikipedia_articles(wiki_categories)
    print("Download data completed!")


if __name__ == "__main__":
    main()
